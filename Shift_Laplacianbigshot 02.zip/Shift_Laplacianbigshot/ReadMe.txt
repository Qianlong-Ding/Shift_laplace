Software required: Ubuntu, Intel® HPC Toolkit, Intel® oneAPI Base Toolkit, Seismic Unix


Compile the files in the folder src_forward0916, and then run the file 002_FDFD_timeslice.job.
